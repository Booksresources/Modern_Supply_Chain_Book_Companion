# Chapter 7 Analytics Toolkit: safety stock and reorder points
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

from scipy.stats import norm
import math
d, sd, L, sL = 80, 20, 9, 2
for csl in [0.90, 0.95, 0.98, 0.99, 0.999]:
    z = norm.ppf(csl)
    ss1 = z * sd * math.sqrt(L)
    ss2 = z * math.sqrt(L * sd**2 + d**2 * sL**2)
    print(f"{csl:.1%}  z={z:.3f}  SS={ss1:.0f}/{ss2:.0f}  ROP={d*L+ss1:.0f}/{d*L+ss2:.0f}")
