# Chapter 5 Analytics Toolkit: SES and Holt forecasting
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

import numpy as np
d = np.array([420,445,430,465,480,455,490,505,495,520,515,540], float)

def ses(d, a=0.3):
    f = [d[0]]                                # forecast for month 2
    for t in range(1, len(d)):
        f.append(a*d[t] + (1-a)*f[-1])        # forecast for month t+2
    return np.array(f)                        # forecasts for months 2..13

def holt(d, a=0.3, b=0.2, L=420.0, T=10.0):
    f = []
    for x in d:
        f.append(L + T)                       # forecast before observing x
        L_new = a*x + (1-a)*(L + T)
        T = b*(L_new - L) + (1-b)*T
        L = L_new
    return np.array(f), L + T                 # in-sample forecasts, next month

def mape(actual, fc):
    return np.mean(np.abs(actual - fc) / actual) * 100

f_ses = ses(d)
f_holt, next_holt = holt(d)
print("SES MAPE :", round(mape(d[1:], f_ses[:-1]), 2), "next:", round(f_ses[-1], 1))
print("Holt MAPE:", round(mape(d, f_holt), 2), "next:", round(next_holt, 1))
