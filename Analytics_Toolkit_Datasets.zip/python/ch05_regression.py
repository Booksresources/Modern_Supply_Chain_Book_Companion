# Chapter 5 / Appendix B: regression with scikit-learn
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

import numpy as np
from sklearn.linear_model import LinearRegression

adv   = np.array([10, 12, 8, 15, 11, 14, 9, 16, 13, 7]).reshape(-1, 1)
sales = np.array([212, 228, 196, 262, 230, 248, 205, 281, 236, 183])
model = LinearRegression().fit(adv, sales)
print("Intercept:", round(model.intercept_, 2), "Slope:", round(model.coef_[0], 2))
print("R2:", round(model.score(adv, sales), 3))
print("Forecast for advertising = 12:", round(model.predict([[12]])[0], 1))
