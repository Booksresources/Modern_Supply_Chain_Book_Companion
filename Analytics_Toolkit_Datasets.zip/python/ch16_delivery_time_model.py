# Chapter 16 Analytics Toolkit: delivery-time prediction
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, r2_score

rng = np.random.default_rng(42); n = 3000
dist  = rng.uniform(2, 60, n);   stops = rng.integers(1, 15, n)
hour  = rng.integers(7, 21, n);  wd    = rng.integers(0, 7, n)
rain  = (rng.random(n) < 0.12).astype(int); van = rng.integers(0, 2, n)
exp_  = rng.uniform(0, 10, n)
peak  = (((hour >= 7) & (hour <= 9)) | ((hour >= 16) & (hour <= 19))).astype(int)
time  = (10 + 1.6*dist + 4.5*stops + 12*peak*(1 + dist/40) + 9*rain
         + 3*(wd == 4) - 0.8*exp_ + 6*van + rng.normal(0, 6, n))

X = np.column_stack([dist, stops, hour, wd, rain, van, exp_])
Xtr, Xte, ytr, yte = train_test_split(X, time, test_size=0.25, random_state=1)
model = GradientBoostingRegressor(n_estimators=300, max_depth=3,
                                  learning_rate=0.05, random_state=1)
model.fit(Xtr, ytr)
pred = model.predict(Xte)
print("MAE:", round(mean_absolute_error(yte, pred), 1), "R2:", round(r2_score(yte, pred), 3))
print("Example route:", round(model.predict([[25, 8, 17, 2, 1, 0, 4]])[0], 1), "minutes")
