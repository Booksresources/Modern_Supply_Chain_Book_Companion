# Chapter 9 / Appendix B: Monte Carlo reorder point
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

import numpy as np

rng = np.random.default_rng(3)
trials = 10_000
lead_times = rng.integers(7, 12, trials)                   # 7 to 11 days
ltd = np.array([rng.normal(80, 20, L).sum() for L in lead_times])
for rop in (860, 931):
    print(rop, "stock-out probability:", round((ltd > rop).mean() * 100, 1), "%")
print("95th percentile of lead-time demand:", round(np.percentile(ltd, 95)))
