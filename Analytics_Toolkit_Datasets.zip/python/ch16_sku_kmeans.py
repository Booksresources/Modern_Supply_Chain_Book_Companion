# Chapter 16 Worked Example 16.1: SKU segmentation with k-means
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

df = pd.read_csv("../csv/ch16_sku_segmentation.csv")
X = StandardScaler().fit_transform(df[["avg_weekly_demand", "coef_variation"]])
df["cluster"] = KMeans(n_clusters=3, n_init=10, random_state=0).fit_predict(X)
print(df.groupby("cluster").agg(skus=("sku", "count"), demand=("avg_weekly_demand", "mean"), cv=("coef_variation", "mean")).round(2))
