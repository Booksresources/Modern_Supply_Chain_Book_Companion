# Chapter 16: delivery-time model trained on the CSV dataset
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error

df = pd.read_csv("../csv/ch16_delivery_times.csv")
X, y = df.drop(columns="delivery_minutes"), df["delivery_minutes"]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=1)
m = GradientBoostingRegressor(n_estimators=300, max_depth=3, learning_rate=0.05, random_state=1).fit(Xtr, ytr)
print("MAE:", round(mean_absolute_error(yte, m.predict(Xte)), 1))
print(pd.Series(m.feature_importances_, index=X.columns).sort_values(ascending=False).round(3))
