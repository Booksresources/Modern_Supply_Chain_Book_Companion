# Chapter 4 Analytics Toolkit: bullwhip simulation
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

import numpy as np
rng = np.random.default_rng(21)
p, L, weeks = 6, 2, 71
demand = np.round(rng.normal(100, 10, weeks))

def stage_orders(d):
    q = np.full(len(d), np.nan)
    S_prev = None
    for t in range(p, len(d)):
        S = L * d[t-p:t].mean()          # order-up-to level
        if S_prev is not None:
            q[t] = S - S_prev + d[t-1]   # order placed
        S_prev = S
    return q

series = [demand]
for stage in ["Retailer", "Wholesaler", "Distributor", "Factory"]:
    q = stage_orders(series[-1])
    series.append(q[~np.isnan(q)])
n = min(len(s) for s in series)
series = [s[-n:] for s in series]
for s in series:
    print(round(s.std(ddof=1), 1), round(s.var(ddof=1) / series[0].var(ddof=1), 2))
