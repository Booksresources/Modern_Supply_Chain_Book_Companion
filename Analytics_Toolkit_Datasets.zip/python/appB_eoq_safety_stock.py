# Appendix B: EOQ and safety stock
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

import math
from scipy.stats import norm

D, S, H = 24000, 150, 2.40          # annual demand, order cost, holding cost
eoq = math.sqrt(2 * D * S / H)
print("EOQ:", round(eoq))            # 1732

d, sd, L, sL, csl = 80, 20, 9, 2, 0.95
z = norm.ppf(csl)
ss = z * math.sqrt(L * sd**2 + d**2 * sL**2)
print("Safety stock:", round(ss), "ROP:", round(d * L + ss))   # 281, 1001
