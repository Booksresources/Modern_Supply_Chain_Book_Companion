# Chapter 9 / Appendix B: product-mix LP with SciPy
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

from scipy.optimize import linprog

c = [-50, -40]                       # maximise 50x + 40y -> minimise -50x - 40y
A_ub = [[2, 1], [1, 1], [1, 0]]      # machine, labour, demand for A
b_ub = [100, 80, 40]
res = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=[(0, None), (0, None)])
print("x, y =", res.x.round(2), "profit =", -res.fun)   # [20, 60], 3400
