# Chapter 9 Analytics Toolkit: transportation problem
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

import numpy as np
from scipy.optimize import linprog

cost = np.array([[4, 6, 9, 5], [7, 3, 4, 8], [6, 8, 3, 4]])
supply = [2500, 3000, 2000]
demand = [1800, 2200, 1500, 2000]
m, n = cost.shape
A_ub = [np.r_[np.zeros(i * n), np.ones(n), np.zeros((m - i - 1) * n)] for i in range(m)]
A_eq = [[1 if k % n == j else 0 for k in range(m * n)] for j in range(n)]
res = linprog(cost.flatten(), A_ub=A_ub, b_ub=supply, A_eq=A_eq, b_eq=demand)
print(res.x.reshape(m, n).round())
print("Total cost:", round(res.fun))   # 27800
