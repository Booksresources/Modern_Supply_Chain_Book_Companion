# Appendix B: ABC classification with pandas
# A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

import pandas as pd

items = pd.DataFrame({
    "item":  ["A101","A102","A103","A104","A105","A106","A107","A108","A109","A110"],
    "units": [1200, 300, 8000, 150, 2400, 600, 90, 5000, 1000, 250],
    "cost":  [95, 40, 2.5, 320, 18, 6, 850, 1.2, 12, 4]})
items["value"] = items["units"] * items["cost"]
items = items.sort_values("value", ascending=False)
items["cum_pct"] = items["value"].cumsum() / items["value"].sum() * 100
items["class"] = pd.cut(items["cum_pct"], [0, 71, 94, 100], labels=["A", "B", "C"])
print(items[["item", "value", "cum_pct", "class"]].round(1))
