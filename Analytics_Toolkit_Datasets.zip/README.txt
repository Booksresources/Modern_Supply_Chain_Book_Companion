Analytics Toolkit Datasets
A Textbook of Modern Supply Chain Management: Strategy, Analytics and AI-Driven Operations

Analytics_Toolkit_Datasets.xlsx  - Excel workbook with one sheet per toolkit or worked example (inputs in blue on yellow; formulas update automatically; Solver-ready models).
csv/                             - Datasets for Python and spreadsheet exercises.
python/                          - Scripts that reproduce the Analytics Toolkits and worked examples.

Run Python scripts from inside the python/ folder (scripts that read CSV files use ../csv/).
Requirements: Python 3.9+, numpy, pandas, scipy, scikit-learn (pip install numpy pandas scipy scikit-learn).
Most datasets are simulated for teaching purposes, as stated in the textbook.
